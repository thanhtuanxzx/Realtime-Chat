<img src="{{ asset('images/anh.png') }}" alt="Logo" class="h-16 w-auto">

