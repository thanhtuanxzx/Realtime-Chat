<img src="<?php echo e(asset('images/anh.png')); ?>" alt="Logo" class="h-16 w-auto">

<?php /**PATH D:\xampp\htdocs\Realtime-Chat\resources\views/components/application-logo.blade.php ENDPATH**/ ?>