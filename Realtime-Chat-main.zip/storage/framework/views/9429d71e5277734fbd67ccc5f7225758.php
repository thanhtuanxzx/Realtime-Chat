<div>
    <div class="chat_container">
        <div class="chat_list_container">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('chat.chat-list');

$__html = app('livewire')->mount($__name, $__params, 'eYbZkil', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
        <div class="chat_box_container">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('chat.chatbox');

$__html = app('livewire')->mount($__name, $__params, 'PCi8RWh', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <div class="chat_box_footer">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('chat.send-message');

$__html = app('livewire')->mount($__name, $__params, '9bwyMQ3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
        
    </div>
    <script>
        $(document).ready(function () {
        window.addEventListener('chatSelected', event=>{
            if(window.innerWidth < 768){
                $('.chat_list_container').hide();
                $('.chat_box_container').show();
            }
            $('.chatbox_body').scrollTop($('.chatbox_body')[0].scrollHeight);
            
            let height = $('.chatbox_body')[0].scrollHeight;
            window.livewire.emit('updateHeight');
            height:height

        })
        
        $(window).resize(function(){
            if(window.innerWidth > 768){
                $('.chat_list_container').show();
                $('.chat_box_container').show();
            }
        });

        $(document).on('click', '.return', function(){
            $('.chat_list_container').show();
            $('.chat_box_container').hide();
        })
    });
    </script>
    <script>
        // //let el= $('#chatBody');
        // let el = document.querySelector('#chatBody');
        // window.addEventListener('scroll', (event) => {
        //     // handle the scroll event 
        //     alert('aasd');
        
        // });
        $(document).on('scroll','#chatBody',function() {
            alert('aasd');
        
            var top = $('.chatbox_body').scrollTop();
            if (top == 0) {
                
                window.livewire.emit('loadmore');
            }
        
        
        });
        
        </script>
</div><?php /**PATH D:\xampp\htdocs\Realtime-Chat\resources\views/livewire/chat/main.blade.php ENDPATH**/ ?>