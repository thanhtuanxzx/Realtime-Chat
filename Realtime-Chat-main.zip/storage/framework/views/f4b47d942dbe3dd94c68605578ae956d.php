<div class="">
    <!--[if BLOCK]><![endif]--><?php if($selectedConversation): ?>
        <div class="chatbox_header">
            <div class="return">
                <i class="bi bi-arrow-left"></i> 
            </div>
            <div class="img_container">
                <img src="https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=<?php echo e($receiverInstance->name); ?>" alt="">
            </div>
            <div class="name"><?php echo e($receiverInstance->name); ?></div>
            <div class="info">
                <div class="info_item">
                    <i class="bi bi-telephone-fill"></i> 
                </div>
                <div class="info_item">
                    <i class="bi bi-image"></i> 
                </div>
                <div class="info_item">
                    <i class="bi bi-info-circle-fill"></i> 
                </div>
            </div>
        </div>

        <div class="chatbox_body">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div wire:key='<?php echo e($message->id); ?>' class="msg_body <?php echo e(auth()->id() == $message->sender_id? 'msg_body_me':'msg_body_receiver'); ?>" style="width:80%;max-width:80%;max-width:max-content">
                    <?php echo e($message->body); ?>

                    <div class="msg_body_footer">
                        <div class="date">
                            <?php echo e($message->created_at->format('m: i a')); ?>

                        </div>
                        <div class="read">
                            <i class="bi bi-check"></i>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </div>
        <script>
            $(".chatbox_body").on('scroll', function(){
                var top = chatboxBody.scrollTop();
                if (top === 0) {
                    window.livewire.emit('loadmore');
                }
         })
             
         </script>
        
    <?php else: ?>
        <div class="fs-4 text-center text-primary mt-5">
            No conversation selected
        </div>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

    
    
</div>


<?php /**PATH D:\xampp\htdocs\Realtime-Chat-main\resources\views/livewire/chat/chatbox.blade.php ENDPATH**/ ?>