<div>
    
<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ul class="list-group w-75 mx-auto mt-3 container-fluid ">
    <li class="list-group-item list-group-item-action" wire:click='checkconversation(<?php echo e($user->id); ?>)'><?php echo e($user->name); ?></li>
</ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\xampp\htdocs\Realtime-Chat\resources\views/livewire/chat/create-chat.blade.php ENDPATH**/ ?>